# web design day 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/sserranovar/pen/jOpmgoQ](https://codepen.io/sserranovar/pen/jOpmgoQ).

